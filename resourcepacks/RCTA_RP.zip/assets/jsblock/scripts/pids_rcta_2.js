include(Resources.id("jsblock:scripts/pids_rcta_util.js"));

function render(ctx, state, pids) {
    // Background
    Texture.create("Background")
        .texture(RCTA_CONFIG.TEX_BACKGROUND)
        .size(pids.width, pids.height)
        .draw(ctx);

    let arrival = pids.arrivals().get(0);

    // 2. Logic view
    if (arrival != null && !pids.isRowHidden(0)) {
        let willArriveIn = arrival.arrivalTime() - Date.now();

        if (willArriveIn <= RCTA_CONFIG.REFRESH_RATE) {
            renderArrivalView(ctx, pids, arrival);
        } else {
            renderIdleView(ctx, pids);
        }
    } else {
        renderIdleView(ctx, pids);
    }
}

// Next train
function renderArrivalView(ctx, pids, arrival) {
    const lang = PIDSCustomUtil.getCurrentLanguagePack();
    let routeColor = arrival.routeColor();
    let stopsText = PIDSCustomUtil.formatStops(arrival, pids.station().getName());
    
    // Icon line and bar
    Texture.create("RouteBox")
        .texture(RCTA_CONFIG.TEX_ROUTE_BASE)
        .color(routeColor).pos(0, 0).size(50, 60).draw(ctx);
    
    Texture.create("Separator")
        .texture(RCTA_CONFIG.TEX_ROUTE_BASE)
        .color(routeColor).pos(136, 0).size(1, pids.height).draw(ctx);

    // Num route // This is for multi line shitting
     PIDSCustomUtil.drawMultiLineText(ctx, arrival.routeNumber(), 25, 10, 20, 20, RCTA_CONFIG.COLOR_BLACK, 2);
    
    //Center ETA text
    PIDSCustomUtil.drawMultiLineText(ctx, lang.ETA2, 162, 15, 40, 10, routeColor, 0.9);

    if (stopsText === "TERMINAL"){
        PIDSCustomUtil.drawMultiLineText(ctx, lang.END, 92.5, 20, 100, 10, RCTA_CONFIG.COLOR_RED_WARNING, 1);
    } else {
        // Innfo dynamic
        drawLabel(ctx, lang.DEST, routeColor, 50, 1, 1.1);
        Text.create("Dest")
        .text(arrival.destination())
        .color(RCTA_CONFIG.COLOR_BLACK).pos(50, 11).scale(0.9).draw(ctx);

        drawLabel(ctx, lang.STOPS, routeColor, 50, 35, 1.1);
        
        Text.create("Stops")
        .text(stopsText)
        .color(RCTA_CONFIG.COLOR_BLACK).pos(50, 47).size(80, 6).marquee().draw(ctx);
    }
    

    Text.create("Time")
        .text(PIDSCustomUtil.getETAText(arrival.arrivalTime()))
        .color(RCTA_CONFIG.COLOR_BLACK).pos(160.7, 35).centerAlign().scale(0.9).draw(ctx);
}

// Logo view (Logo RCTA + watch)
function renderIdleView(ctx, pids) {
    Texture.create("Logo")
        .texture(RCTA_CONFIG.TEX_LOGO)
        .pos(0, 1).size(148, 56).draw(ctx);

    Text.create("Clock")
        .text(PIDSCustomUtil.formatTime(MinecraftClient.worldDayTime()))
        .color(RCTA_CONFIG.COLOR_BLUE).pos(145, 25).scale(1.7).draw(ctx);
}

// Auxiliary fuction to save time of my life writing code. thx AI for propose this i guess
function drawLabel(ctx, txt, clr, x, y, sc) {
    Text.create().text(txt).color(clr).pos(x, y).scale(sc).draw(ctx);
}