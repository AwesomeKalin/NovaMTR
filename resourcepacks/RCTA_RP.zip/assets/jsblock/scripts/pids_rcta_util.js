// Identiti RCTA and some things
const RCTA_CONFIG = {
    // Colors
    COLOR_BLACK: 0x000000,
    COLOR_BLUE: 0x2C598F,
    COLOR_YELLOW_TRAFFIC: 0xF7D117,
    COLOR_RED_WARNING: 0xFF0000,
    
    // Textures
    TEX_BACKGROUND: "jsblock:textures/white_route_template.png",
    TEX_LOGO: "jsblock:textures/rcta_logo.png",
    TEX_ROUTE_BASE: "jsblock:textures/white_route_template.png",
    //Texts
    
    // Times
    REFRESH_RATE: 180000 // 3 minute for change displays
};
const RCTA_TEXTS = {
    es: {
        DEST: "Destino:",
        ETA: "Tiempo estimado:",
        ETA2: "Tiempo|estimado:",
        STOPS: "Con parada en:",
        ARRIVED: "Estacionado",
        END: "ESTE TREN|FINALIZA AQUÍ"
    },
    en: {
        DEST: "Destination:",
        ETA: "Estimated time:",
        ETA2: "Estimated|time:",
        STOPS: "Stopping at:",
        ARRIVED: "Arrived",
        END: "THIS TRAIN|TERMINATES HERE"
    }
};

let lastLangChange = Date.now();
let currentLang = "en";

const PIDSCustomUtil = {
    _blinkToggle: false,
    _lastBlinkTime: 0,

    getETAText(arrivalArrivalTime) {
        let willArriveIn = arrivalArrivalTime - Date.now();
        let willArriveInSec = Math.floor(willArriveIn / 1000);
        
        if (willArriveInSec <= 0) {
            let now = Date.now();
            if (now - this._lastBlinkTime > 800) {
                this._blinkToggle = !this._blinkToggle;
                this._lastBlinkTime = now;
            }
            return this._blinkToggle ? this.getCurrentLanguagePack().ARRIVED : "";
        } else if (willArriveIn <= 60000) {
            return `${willArriveInSec} seg`;
        } else if (willArriveIn <= 120000) {
            return `${Math.floor(willArriveInSec / 60)} min`;
        } else {
            return `${Math.floor(willArriveInSec / 60)} mins`;
        }
    },

    formatTime(inGameTime) {
        let timeNow = inGameTime + 6000;
        let hrs = Math.floor((timeNow / 1000) % 24);
        let mins = Math.floor(((timeNow / 1000) % 1) * 60);
        return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
    },

    getCurrentLanguagePack() {
        let now = Date.now();
        // Cambia el idioma cada 4000ms (4 segundos)
        if (now - lastLangChange > 4000) {
            currentLang = (currentLang === "en") ? "es" : "en";
            lastLangChange = now;
        }
        return RCTA_TEXTS[currentLang];
    },
    drawMultiLineText(ctx, fullText, x, y, sizeW, sizeH, color, scale) {
        let normalizedText = fullText.toString().replace("|", "#").replace("\\|", "#");
        let parts = normalizedText.split("#"); 
        for (let i = 0; i < parts.length; i++) {
            Text.create("MultiLineText")
                .text(parts[i])
                .color(color)
                .centerAlign()
                .size(sizeW, sizeH)
                .stretchXY() // Esto asegura que rellene el hueco
                .pos(x, y + (i * sizeH)) // Baja la posición Y según el alto de la línea
                .scale(scale) // Opcional, stretchXY suele ignorar el scale
                .draw(ctx);
        }
    },
    
    // code copied from teampommes
    formatStops(arrival, pidsStationName) {
        let stops = arrival.route().getPlatforms().toArray().map(p => p.stationName.replace("|", " "));
        let stationClean = pidsStationName.normalize("NFC").trim();
        let currentIndex = stops.findIndex(s => s.normalize("NFC").trim() === stationClean);
        
        let remainingStops = stops.slice(currentIndex + 1);
        if (remainingStops.length === 0) return "TERMINAL";
        
        if (remainingStops.length === 1) return remainingStops[0] + ".";
        
        let lastStop = remainingStops.pop();
        let connector = (currentLang === "en") ? " & " : " y ";
        return remainingStops.join(", ") + connector + lastStop + ".";
    }
};