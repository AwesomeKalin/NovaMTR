include("jsblock:scripts/util/pids_util.js");
function create(ctx, state, pids) {
    state.blinkTimer = 0;
}
function dispose(ctx, state, pids) {}
function render(ctx, state, pids) {
    state.blinkTimer++;
    let arrivals = pids.arrivals();
    let now = Date.now();
    Texture.create()
        .texture("mtr:textures/block/white.png")
        .color(0x000000)
        .size(pids.width, pids.height)
        .draw(ctx);
    let firstTrain = arrivals.get(0);
    let showServiceEnd = false;
    let showArrivalNotice = false;
    let showDoorCloseNotice = false;
    if (!firstTrain) {
        showServiceEnd = true;
    } else {
        let etaArrive = (firstTrain.arrivalTime() - now) / 1000;
        let etaDepart = (firstTrain.departureTime() - now) / 1000;
        showServiceEnd = etaArrive > 5400;
        if (!showServiceEnd) {
            showArrivalNotice = (etaArrive > 0 && etaArrive <= 60);
            showDoorCloseNotice = (etaDepart > 0 && etaDepart <= 10);
        }
    }
    if (showServiceEnd) {
        let baseY = 15;
        Text.create()
            .text("☆☆☆ 本日は終了しました ☆☆☆")
            .pos(pids.width / 2, baseY)
            .scale(1.2)
            .centerAlign()
            .color(0xb9f47f)
            .draw(ctx);
        return;
    }
    if (firstTrain) {
        Texture.create()
            .texture("mtr:textures/block/white.png")
            .color(firstTrain.routeColor())
            .pos(4, 4)
            .size(5, 10)
            .draw(ctx);
        Text.create()
            .text(TextUtil.cycleString(firstTrain.routeName()))
            .pos(14, 5)
            .scale(0.85)
            .color(0xFFFFFF)
            .draw(ctx);
    }
    if (firstTrain) {
        let baseY = 20;
        let rawRoute = firstTrain.routeNumber();
        let routeNumText = (rawRoute !== null && rawRoute !== undefined) ? String(rawRoute).trim() : "";
        let hasRoute = routeNumText.length > 0;
        
        let lineDefaultColor = firstTrain.routeColor();
        let etaArrive = (firstTrain.arrivalTime() - now) / 1000;
        let blockColor = getColorByKeyword(routeNumText, lineDefaultColor);
        Texture.create()
            .texture("mtr:textures/block/white.png")
            .color(blockColor)
            .pos(4, baseY-2)
            .size(32, 13)
            .draw(ctx);

        let displayTypeText;
        if (hasRoute) {
            displayTypeText = routeNumText;
        } else {
            let carCount = firstTrain.carCount();
            displayTypeText = `${carCount}両|${carCount} cars`;
        }
        Text.create()
            .text(TextUtil.cycleString(displayTypeText))
            .pos(20, baseY + 1)
            .size(30, 9)
            .stretchXY()
            .centerAlign()
            .scale(0.85)
            .color(0xFFFFFF)
            .draw(ctx);
            
        if (etaArrive <= 0) {
            Text.create()
                .text(TextUtil.cycleString("着到|Arrived"))
                .pos(pids.width / 2, baseY)
                .scale(1.05)
                .centerAlign()
                .color(0xFFFFFF)
                .draw(ctx);
        } else {
            Text.create()
                .text(formatTime(firstTrain.arrivalTime()))
                .pos(pids.width / 2, baseY)
                .scale(1.05)
                .centerAlign()
                .color(0xFFFFFF)
                .draw(ctx);
        }
        Text.create()
            .text(TextUtil.cycleString(firstTrain.destination()))
            .pos(pids.width - 4, baseY)
            .size(52, 9)
            .stretchXY()
            .rightAlign()
            .scale(1.05)
            .color(0xFFFFFF)
            .draw(ctx);
    }
    let secondTrain = arrivals.get(1);
    let blinkOn = (state.blinkTimer % 30 < 15);
    let noticeY = 44;
    if (showArrivalNotice) {
        if (blinkOn) {
            Text.create().text("🚃").pos(12, noticeY).scale(1.0).color(0xFFDD00).draw(ctx);
            Text.create()
                .text(TextUtil.cycleString("電車がまいります|Train arriving"))
                .pos(pids.width / 2, noticeY)
                .scale(1.1)
                .centerAlign()
                .color(0xFFDD00)
                .draw(ctx);
            Text.create().text("🚃").pos(pids.width - 12, noticeY).scale(1.0).rightAlign().color(0xFFDD00).draw(ctx);
        }
    } else if (showDoorCloseNotice) {
        Text.create()
            .text(TextUtil.cycleString("ドアが閉まります|Door closing"))
            .pos(pids.width / 2, noticeY)
            .scale(1.1)
            .centerAlign()
            .color(0xFFDD00)
            .draw(ctx);
    } else {
        if (secondTrain) {
            let baseY = 44;
            let rawRoute = secondTrain.routeNumber();
            let routeNumText = (rawRoute !== null && rawRoute !== undefined) ? String(rawRoute).trim() : "";
            let hasRoute = routeNumText.length > 0;
            
            let lineDefaultColor = secondTrain.routeColor();
            let blockColor = getColorByKeyword(routeNumText, lineDefaultColor);
            Texture.create()
                .texture("mtr:textures/block/white.png")
                .color(blockColor)
                .pos(4, baseY-2)
                .size(32, 13)
                .draw(ctx);

            let displayTypeText2;
            if (hasRoute) {
                displayTypeText2 = routeNumText;
            } else {
                let carCount = secondTrain.carCount();
                displayTypeText2 = `${carCount}両|${carCount} cars`;
            }
            Text.create()
                .text(TextUtil.cycleString(displayTypeText2))
                .pos(20, baseY + 1)
                .size(30, 9)
                .stretchXY()
                .centerAlign()
                .scale(0.85)
                .color(0xFFFFFF)
                .draw(ctx);
                
            Text.create()
                .text(formatTime(secondTrain.arrivalTime()))
                .pos(pids.width / 2, baseY)
                .scale(1.05)
                .centerAlign()
                .color(0xFFFFFF)
                .draw(ctx);
            Text.create()
                .text(TextUtil.cycleString(secondTrain.destination()))
                .pos(pids.width - 4, baseY)
                .size(52, 9)
                .stretchXY()
                .rightAlign()
                .scale(1.05)
                .color(0xFFFFFF)
                .draw(ctx);
        }
    }
}
function getColorByKeyword(text, defaultColor) {
    switch (text) {
        case "区間快速":
        case "Semi-Rapid":
            return 0x00AA00;
        case "特急":
        case "Limited Express":
            return 0xFFCC00;
        case "急行":
        case "Express":
            return 0xFF8800;
        case "快速":
        case "Rapid":
            return 0xCC2222;
        case "各停":
        case "Local":
            return 0x0066CC;
        default:
            return defaultColor;
    }
}
function formatTime(timestamp) {
    let date = new Date(timestamp);
    let h = String(date.getHours()).padStart(2, "0");
    let m = String(date.getMinutes()).padStart(2, "0");
    return h + ":" + m;
}