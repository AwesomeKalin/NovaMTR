------------------------------------
IVR - Japan Sign Pack v.1.0.0 by Ukfa
------------------------------------
Discord: 
https://discord.gg/D6ZHrV9rUr
------------------------------------
Support me 支持我:
https://patreon.com/Ukfa
------------------------------------
Overview
This pack main features Japan style or more style Signs, with feature of IVR Gameplay Server

====================================
Terms of use 使用守則:
1. No Share Actual Files. No Publish. 
   禁止轉發、發佈實際文件。
2. Share Download Link Only. Permission using on videoes sharing with credit.
   只允許直接分享檔案下載連結，及允許用於發佈影片內容(需附註明此材質包)。
3. No modification is allowed without the author's consent.
   未經作者許可，禁止編輯及發佈作品
4. Corresponding to the above, the model/textures you modify, may requested to add into IVR pack.
   承上，若取得作者許可，經二次修改的作品可能會被要求納入IVR材質包裏
5. Any inconsistency between the Chinese version and any other language of the Terms, 
   The Chinese version of this Agreement shall prevail.
   若上方有任何語言翻譯的意思有不一致之處，一律以繁體中文為準
====================================
Log
====================================

v.1.0.0(22/9/2025):
Add (Normal / White Outline):

1. JR Logos (Black, Central, East, West, Shikoku, Kyushu, Info Systems, White), 
2. JR Lines Symbols (Line Symbol, JA, JB, JC, JE, JH, JI, JJ, JK, JL, JM, JN, JO, JS, JT, JU, JY, MO)
3. Tokyo Metro, Toei Subway Logo
4. Tokyo Metro / Toei Subway Line Symbols (A, C, E, F, G, H, I, M, N, S, T, Y, Z)
5. Tokyu Lines (MM, DT, IK, KD, MG, OM, SG, SH, TM, TY)
6. Tsukuba Express Logo (TX)
7. Yurikamome Line (U)
8. Rinkai Line (TWR)
9. KeiKyu Line (KK)