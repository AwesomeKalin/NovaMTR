include(Resources.id("jsblock:scripts/pids_util.js"));
 
// ============================================================
//  SILDURGRUND AIRPORT — Terminal 1 Departure Board
//
//  LAYOUT (absolute units):
//    y=  0 → 16   Header bar  (route colour, cycled route name)
//    y= 16 → 54   Content     (number if present, dest, time)
//    y= 54 → 63   Status bar  (dynamic colour, no gap)
//    y= 63 → end  Marquee     (clock left | scroll starts after clock)
//
//  ROUTE NAME CYCLING:
//    Split on |. Segments preceded by || are omitted.
//    e.g. "Chinese|English||Ignored" → cycles "Chinese" / "English"
//    Each segment shown for 8 seconds.
//
//  STATUS THRESHOLDS (minutes until departure):
//    > 15  →  dark grey  "Awaiting Gate Information"
//    ≤ 15  →  orange     "Gate Not Opened Yet"
//    ≤ 10  →  deep blue  "Gate Opened"
//    ≤  0  →  green      "Boarding"
//    < -5  →  deep red   "Gate Closed"
// ============================================================
 
function create(ctx, state, pids) {}
 
function render(ctx, state, pids) {
 
    // ── First arrival ─────────────────────────────────────────
    let arrival      = pids.arrivals().get(0);
    let routeNumber  = "";
    let destination  = "";
    let routeName    = "";
    let departureStr = "--:--";
    let minsUntil    = 9999;
    let minsUntilArrival = 9999;
    let headerColor  = 0x2A2E6E;
 
    if (arrival != null) {
        routeNumber  = arrival.routeNumber() || "";
        destination  = arrival.destination()  || "";
        routeName    = arrival.routeName()     || "";
        headerColor  = arrival.routeColor();
 
        let depTs    = arrival.departureTime();
        let depDate  = new Date(depTs);
        departureStr = depDate.getHours().toString().padStart(2, '0') + ":" +
                       depDate.getMinutes().toString().padStart(2, '0');
        minsUntil         = (depTs - Date.now()) / 60000;
        minsUntilArrival  = (arrival.arrivalTime() - Date.now()) / 60000;
    }
 
    // ── Route name: show everything up to the first |  ───────
    // "Chinese|English||Extra" → "Chinese"
    let pipe = String.fromCharCode(124);
    let routeSegments = String(routeName).split(pipe).map(s => s.trim()).filter(s => s !== "");
    let displayName = routeSegments.length > 0
        ? routeSegments[Math.floor(Date.now() / 6000) % routeSegments.length]
        : "Sildurgrund Airport — Terminal 1";
 
    // ── Status colour + label ─────────────────────────────────
    let statusColor;
    let statusText;
 
    if (arrival != null && minsUntil >= 35) {
        statusColor = 0xB01020;
        statusText  = "Gate Closed";
    } else if (arrival != null && minsUntilArrival <= 0) {
        statusColor = 0x0A9940;
        statusText  = "Boarding";
    } else if (arrival != null && minsUntil <= 0) {
        statusColor = 0x0A9940;
        statusText  = "Boarding";
    } else if (arrival != null && minsUntilArrival <= 10) {
        statusColor = 0x0D4BF2;
        statusText  = "Gate Opened";
    } else if (arrival != null) {
        statusColor = 0xE07000;
        statusText  = "Gate Not Opened Yet";
    } else {
        statusColor = 0x2A2A2A;
        statusText  = "Awaiting Gate Information";
    }
 
    // ── Real-time clock ───────────────────────────────────────
    let now      = new Date();
    let timeStr  = now.getHours().toString().padStart(2, '0') + ":" +
                   now.getMinutes().toString().padStart(2, '0');
    let months   = ["Jan","Feb","Mar","Apr","May","Jun",
                    "Jul","Aug","Sep","Oct","Nov","Dec"];
    let dateStr  = now.getDate() + " " + months[now.getMonth()] + " " +
                   now.getFullYear();
    let clockStr = dateStr + "  " + timeStr;
 
    let X = 3;
 
    // ══════════════════════════════════════════════════════════
    //  BACKGROUND
    // ══════════════════════════════════════════════════════════
 
    Texture.create("bg")
        .texture("jsblock:custom_directory/black.png")
        .size(pids.width, pids.height)
        .pos(0, 0)
        .zOrder(0)
        .draw(ctx);
 
    // ══════════════════════════════════════════════════════════
    //  HEADER BAR   y: 0 → 16
    //  Route colour. Cycled name, hard-capped to 11u height.
    // ══════════════════════════════════════════════════════════
 
    Texture.create("header_bg")
        .texture("jsblock:custom_directory/stripe.png")
        .size(pids.width, 16)
        .pos(0, 0)
        .color(headerColor)
        .zOrder(1)
        .draw(ctx);
 
    Text.create("header_text")
        .text(displayName)
        .pos(X, 3)
        .scale(1.0)
        .size(pids.width - X * 2, 11)
        .scaleXY()
        .color(0xFFFFFF)
        .zOrder(2)
        .draw(ctx);
 
    // ══════════════════════════════════════════════════════════
    //  CONTENT AREA   y: 16 → 54  (38u)
    //  Line 1 — route number (only if non-empty)  y=18
    //  Line 2 — destination                       y=31
    //  Line 3 — departure                         y=44
    //  All hard-capped to full width minus margins.
    // ══════════════════════════════════════════════════════════
 
    Texture.create("content_bg")
        .texture("jsblock:custom_directory/stripe.png")
        .size(pids.width, 38)
        .pos(0, 16)
        .color(0x141318)
        .zOrder(1)
        .draw(ctx);
 
    if (routeNumber !== "") {
        Text.create("line_number")
            .text(routeNumber)
            .pos(X, 18)
            .scale(1.1)
            .size(pids.width - X * 2, 9)
            .scaleXY()
            .color(0xFFFFFF)
            .zOrder(2)
            .draw(ctx);
    }
 
    Text.create("line_dest")
        .text((() => {
            if (destination === "") return "---";
            let segs = String(destination).split(pipe).map(s => s.trim()).filter(s => s !== "");
            return segs[Math.floor(Date.now() / 6000) % segs.length];
        })())
        .pos(X, 31)
        .scale(1.1)
        .size(pids.width - X * 2, 9)
        .scaleXY()
        .color(0xFFFFFF)
        .zOrder(2)
        .draw(ctx);
 
    Text.create("line_dep")
        .text("Departing  " + departureStr + "  Hrs")
        .pos(X, 44)
        .scale(1.1)
        .size(pids.width - X * 2, 9)
        .scaleXY()
        .color(0xFFFFFF)
        .zOrder(2)
        .draw(ctx);
 
    // ══════════════════════════════════════════════════════════
    //  STATUS BAR   y: 54 → 63  (9u)
    //  Sits directly below content — no gap.
    //  Full-width. ONLY this bar changes colour.
    // ══════════════════════════════════════════════════════════
 
    Texture.create("status_bg")
        .texture("jsblock:custom_directory/stripe.png")
        .size(pids.width, 9)
        .pos(0, 54)
        .color(statusColor)
        .zOrder(1)
        .draw(ctx);
 
    Text.create("status_text")
        .text(statusText)
        .pos(pids.width / 2, 55)
        .centerAlign()
        .scale(1.0)
        .size(pids.width - 6, 7)
        .scaleXY()
        .color(0xFFFFFF)
        .zOrder(2)
        .draw(ctx);
 
    // ══════════════════════════════════════════════════════════
    //  MARQUEE BAR   y: 63 → pids.height  (bottom-anchored)
    //
    //  Clock occupies the LEFT portion (static text).
    //  Scroll text starts AFTER the clock with a small gap,
    //  so the two never overlap.
    //
    //  Midpoint alignment:
    //    clock  scale=0.85 → height=6.8 → mid offset=3.4 → top y=65.0
    //    marquee scale=0.5 → height=4.0 → mid offset=2.0 → top y=66.4
    //    Both midpoints sit at y=68.4.
    //
    //  Smooth scrolling: NO .scaleXY() on the marquee — that
    //  was causing letter-by-letter chunky rendering.
    //  Just .scale() + .marquee() = pixel-smooth scroll.
    // ══════════════════════════════════════════════════════════
 
    Texture.create("marquee_bg")
        .texture("jsblock:custom_directory/stripe.png")
        .size(pids.width, pids.height - 63)
        .pos(0, 63)
        .color(0x0E101C)
        .zOrder(1)
        .draw(ctx);
 
    // Clock — static, left side, fits within left 32% of width
    Text.create("clock_text")
        .text(clockStr)
        .pos(X, 65)
        .scale(0.85)
        .size(pids.width * 0.32, pids.height - 67)
        .scaleXY()
        .color(0xFFFFFF)
        .zOrder(2)
        .draw(ctx);
 
    // Scrolling text — starts at 56% width, y nudged to share midpoint with clock
    // NO .scaleXY() here → pixel-smooth scrolling, no letter-snapping
    Text.create("marquee_text")
        .text(
            "Please do not litter at the Airport — $500 fine.   " +
            "Welcome to Terminal 1 at Sildurgrund Airport.   " +
            "Thank you for travelling with us.   " +
            "Did you know? This Terminal was built very long ago!"
        )
        .pos(pids.width * 0.56 - 30, 66.4)
        .scale(0.5)
        .size(pids.width - (pids.width * 0.56 - 30) + 70, pids.height - 67)
        .marquee()
        .color(0xFFFFFF)
        .zOrder(2)
        .draw(ctx);
 
}
 
function dispose(ctx, state, pids) {}