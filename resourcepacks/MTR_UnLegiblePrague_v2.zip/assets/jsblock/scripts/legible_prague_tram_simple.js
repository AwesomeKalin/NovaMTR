importPackage(java.awt);

// Default text size = 9

/*
(A) Station Name - Height 10 - Font Scale 0.75
  --empty block-- - Height 0.1

  --empty block-- - Height 0.1
Monday 1.1.1999   15:00 - Height 5 - Font Scale 0.55
*/

include(Resources.id("jsblock:scripts/pids_util.js"));

function create(ctx, state, pids) {
}

function render(ctx, state, pids) {

  const topBlockHeight = 10;
  const emptyBlockHeight = 0.1;
  const lineThickness = 0.5;
  const desLineThikness = 7.4;
//const lineThickness = 0.5;
  const bottomBlockHeight = 5;

  // Text scaling
  const stationFontScale = 0.75; // Scale 0.75
  const desFontScale = 0.6; // Font size 5.4 - Scale 0.6
  const timeFontScale = 0.55;// Font size 5 - Scale 0.55

  // Position constants
  const stationXPos = 30; //25


  // Custom messages constants
  const msgMarquee = pids.getCustomMessage(1);
  const msgNoArrivals = pids.getCustomMessage(0);
  const msgNoArrivalsOffset = 5;

  // Graphic helpers
  const topBorder = 0
  const bottomBorder = (msgMarquee == "") // Tests if there is rolling information
    ? pids.height
    : pids.height - lineThickness - bottomBlockHeight - 1; // 2 is used, to have there slightly larger gap between date/time and rolling info

  const usableSpace = bottomBorder - topBorder;
  const numberOfLines = Math.floor(usableSpace / desLineThikness);

  const firstLineOffset = ((usableSpace - (numberOfLines*desLineThikness))/2) + topBorder + 1; // 1 is used to shift the block for half of the thickness of space between destinations


  Texture.create("Bottom Line")
  .texture("jsblock:custom_directory/white.png")
  .size(pids.width, lineThickness)
  .pos(0,bottomBorder)
  .draw(ctx);

  // Middle Part
  if((msgNoArrivals=="")&&(pids.arrivals().get(0)!=null)){
    for(let i=0;i<numberOfLines;i++) {
      let arrival = pids.arrivals().get(i);
      if(arrival != null) {
        Text.create("Line Number")
        .text(arrival.routeNumber())
        .pos(13.5,firstLineOffset+(desLineThikness*i))
        .rightAlign()
        .scale(desFontScale)
        .color(0xFFFFFF)
        .bold()
        .draw(ctx);

        if(arrival.terminating()==true){
          Text.create("Destination")
          .text("Terminates here")
          .pos(stationXPos,firstLineOffset+(desLineThikness*i))
          .leftAlign()
          .scale(desFontScale)
          .color(0xFFFFFF)
          .bold()
          .draw(ctx);
        }
        else {
          Text.create("Destination")
          .text(TextUtil.cycleString(arrival.destination(),80))
          .pos(stationXPos,firstLineOffset+(desLineThikness*i))
          .leftAlign()
          .scale(desFontScale)
          .color(0xFFFFFF)
          .bold()
          .draw(ctx);
        }

        let eta = (arrival.arrivalTime() - Date.now()) / 60000;
        eta = Math.round(eta);

        if(eta=="0"){
          Text.create("ETA")
          .text("<1")
          .pos(pids.width,firstLineOffset+(desLineThikness*i))
          .rightAlign()
          .scale(desFontScale)
          .color(0xFFFFFF)
          .bold()
          .draw(ctx);
        }
        else
        {
          Text.create("ETA")
          .text(eta)
          .pos(pids.width,firstLineOffset+(desLineThikness*i))
          .rightAlign()
          .scale(desFontScale)
          .color(0xFFFFFF)
          .bold()
          .draw(ctx);
        }

      }
      
    }
  }
  else
  {
    Text.create("Message insted of Departure Board")
    .text(msgNoArrivals)
    // .pos(msgNoArrivalsOffset,topBorder+5)
    .pos(msgNoArrivalsOffset,topBorder+5)
    .leftAlign()
    .size((pids.width*(1/desFontScale))-21,1)
    .wrapText()
    .scale(desFontScale)
    .color(0xFFFFFF)
    .draw(ctx);
  }

  // Bottom part
  if(msgMarquee!="")
  {
    Text.create("Marquee Message")
    .text(msgMarquee)
    .pos(0,pids.height - bottomBlockHeight - 1)
    .leftAlign()
    .size((pids.width*(1/timeFontScale))-(msgNoArrivalsOffset*(1/timeFontScale)),1)
    .scale(timeFontScale)
    .marquee()
    .color(0xFFFFFF)
    .draw(ctx);
  }
}

function dispose(ctx, state, pids) {
}
