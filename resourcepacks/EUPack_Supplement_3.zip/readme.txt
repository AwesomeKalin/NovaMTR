
EU Pack version 0.5 alpha
Build: 2026.07.11

This pack is curently in alpha so if there are any errors please tell me via DMs @thehostingmetalpetal on discord

Huge thanks to @aecththean for allowing me to retexture his models.

This pack is only officially avaiable on project Zuhlteich, Pärail and MTR Discord Servers. If you got this pack from anywhere else, then you got a unofficial version.
